public class Oblig1Oppgave1 {
    public static void main(String[] args) {
        double radius = 23.5;
        System.out.println(Sirkel.areal(radius));
        System.out.println(Sirkel.omkrets(radius));
        System.out.println(Sirkel.diameter(radius));
    }
}
